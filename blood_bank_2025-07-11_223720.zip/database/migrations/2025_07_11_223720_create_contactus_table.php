<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateContactusTable extends Migration {

	public function up()
	{
		Schema::create('contactus', function(Blueprint $table) {
			$table->increments('id');
			$table->string('subject', 255);
			$table->text('message');
			$table->integer('client_id')->unsigned();
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('contactus');
	}
}