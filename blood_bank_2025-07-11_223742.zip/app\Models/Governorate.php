<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Governorate extends Model 
{

    protected $table = 'governorates';
    public $timestamps = true;

    public function cities()
    {
        return $this->hasMany('City', 'governorate_id');
    }

    public function clients()
    {
        return $this->belongsToMany('Client');
    }

}